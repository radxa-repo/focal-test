
void btchr_external_write(char* data, int len);

